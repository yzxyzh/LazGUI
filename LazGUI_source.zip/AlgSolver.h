#pragma once

#include <string>
#include "mainwindow.h"
#include <QObject>

class AlgSolver : public QObject
{
    Q_OBJECT
    
public:
    vector<string> newInstances;
public slots:
    void process();
    
signals:
    void finished();
    void error(QString msg);
    void start(QString msg);
    void end(QString msg);
};
//多线程读取脚本的线程函数
class ScriptReader : public QObject
{
    Q_OBJECT
    
public:
    ScriptReader(QString _baseName);

protected:
    QString baseName;
    
    
public slots:
    void process();
    
    
    
signals:
    //发送给主线程的消息，代表算法已经执行完毕
    void finished(int code,QString error_msg);
};




class CacheSaver : public QObject
{
    Q_OBJECT

public:
    CacheSaver(std::string& path,std::string& instance_name);
public slots:
    void process();

signals:
    void finished();
    //释放进程的progress，percentage代表当前进度百分比，msg代表信息，code代表成攻（1）失败（0）
    void progress(double percentage,QString msg,int code);
    void started();
    void error(QString msg);

private:
    std::string scriptName;
    std::string instanceName;

};


#if 0
namespace AlgSolver {
    

public:
    
    enum {
        ALG_START,
        ALG_END,
        ALG_ERROR
    }solver_type;
    
    //call back function;
    //int call back code;
    //string error message;
    typedef void (*CallBack)(int,std::string); //这是个“形式”上的回调函数
    
    void PharseOneScript_Threaded(CallBack cb = nullptr);
    
}

#endif
